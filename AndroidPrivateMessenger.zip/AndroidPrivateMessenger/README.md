# AndroidPrivateMessenger

안드로이드 메신저를 개발해보고 있습니다.

Firebase Cloud Message 서비스를 최대로 이용해보기 위해 다양한 API 를 사용해볼 예정이며,

개발이 끝나면 내용을 정리해볼 예정입니다.
