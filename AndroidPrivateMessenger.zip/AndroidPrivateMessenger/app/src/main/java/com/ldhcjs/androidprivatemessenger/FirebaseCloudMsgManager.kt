package com.ldhcjs.androidprivatemessenger

object FirebaseCloudMsgManager {

    private val TOKEN: String = "token"
    private val TITLE: String = "title"
    private val BODY: String = "body"

    fun fcmObj(fcmData: HashMap<String, String>) : FirebaseMessageObject {
        val firebaseMessageObject = FirebaseMessageObject()
        val firebaseMessageData = FirebaseMessageData()
        firebaseMessageData.setTitle(fcmData[TITLE])
        firebaseMessageData.setBody(fcmData[BODY])
        firebaseMessageObject.setTo(fcmData[TOKEN])
        firebaseMessageObject.setData(firebaseMessageData)

        return firebaseMessageObject
    }
}